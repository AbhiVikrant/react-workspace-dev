import React from "react";
export default function Skills() {
      return (
            <div className="skills">
                  <ul>
                        <li>Core Java</li>
                        <li>React</li>
                        <li>JavaScript</li>
                        <li>Next JS</li>
                  </ul>
            </div>
      )
}