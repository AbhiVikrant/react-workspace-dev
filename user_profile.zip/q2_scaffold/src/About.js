
import React from "react";
export default function About() {
      return(
            <div className="about">
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Illum ab ullam accusantium modi natus quidem libero minima tempore ut debitis consectetur nostrum pariatur, dicta rerum adipisci, obcaecati expedita ratione quo.
                  Temporibus adipisci nobis sit obcaecati quo ipsa eum praesentium deleniti. Nesciunt ab beatae cum sint dolorem doloremque pariatur minima est molestiae suscipit velit earum officiis, ad maxime, sunt aliquid! Pariatur.</p>
            </div>
      )
}