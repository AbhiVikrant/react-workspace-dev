import React from "react";
export default function Hero(){

      return (
            <div className="hero">
                  <h1><b>Name: Abhishek Kumar Vikrant</b></h1>
                  <p>Email: abhishekvikrantdba123@gmail.com</p>
                  <p>Phone: +91-7979821945</p>

                        <p>Address: Noida HJj 303404</p>

           </div>
      )

}